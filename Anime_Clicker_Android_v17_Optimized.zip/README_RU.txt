ANIME CLICKER: STAR ACADEMY — ANDROID PROJECT (ROOT-READY)

В этой версии структура уже подготовлена для GitHub: файлы должны находиться в корне репозитория.
- web/index.html — HTML5-игра.
- package.json — npm зависимости.
- capacitor.config.json — конфигурация Capacitor.
- .github/workflows/build-apk.yml — workflow сборки debug APK.

Сборка APK через GitHub Actions:
1. Загрузить содержимое папки проекта в корень репозитория на отдельную ветку ci/android-apk-workflow.
2. Открыть GitHub Actions и выбрать Build Android APK.
3. Запустить workflow (Run workflow).
4. После завершения открыть run и скачать Artifact Anime-Clicker-debug-apk.
5. Распаковать artifact и установить app-debug.apk на Android (при необходимости разрешить установку из этого источника).

Workflow убирает npm cache, который требовал отсутствующий package-lock.json. npm install используется для установки зависимостей.
Это debug APK для тестирования, не подписанный release для публикации в Google Play.


Версия 17 — оптимизация частых кликов:
- Обновление верхней панели объединяется в один кадр браузера (requestAnimationFrame).
- Всплывающие цифры ограничены 10 одновременно, чтобы не перегружать DOM.
- Анимация удара и обработка визуальных эффектов ограничены частотой, механический урон кликов сохраняется.
- Сохранение прогресса после кликов объединяется с задержкой 1,5 секунды, вместо записи localStorage каждый клик.
