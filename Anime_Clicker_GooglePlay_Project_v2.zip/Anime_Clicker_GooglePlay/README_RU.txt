ANIME CLICKER: STAR ACADEMY — ANDROID PREPARATION PROJECT

Что это:
- web/index.html — текущая HTML5-игра, подготовленная как Android-версия (без подключения SDK Яндекс Игр).
- package.json и capacitor.config.json — настройки для упаковки в Android-приложение через Capacitor.

Важно:
Этот архив пока НЕ является APK или AAB. Для сборки потребуется компьютер с Node.js, Android Studio и Android SDK.

Шаги на компьютере:
1. Установить Node.js LTS и Android Studio.
2. Распаковать архив.
3. Открыть терминал в папке проекта и выполнить:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
4. В Android Studio дождаться загрузки Gradle и проверить приложение на телефоне.
5. Для тестового APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Для Google Play AAB: Build > Generate Signed Bundle / APK > Android App Bundle.

Пока не подключены Google Play Billing и рекламная сеть. Их будем добавлять после проверки базовой Android-сборки.

СБОРКА APK БЕЗ ANDROID STUDIO (через GitHub Actions)
1. Создай аккаунт/репозиторий на GitHub (можно сделать с телефона в браузере).
2. Загрузи содержимое этой папки в новый репозиторий.
3. Открой вкладку Actions в репозитории.
4. Выбери workflow "Build Android APK" и нажми Run workflow.
5. После завершения успешной сборки открой страницу запуска workflow.
6. В разделе Artifacts скачай Anime-Clicker-debug-apk.
7. Распакуй архив artifact и установи app-debug.apk на Android. Если Android попросит, разреши установку из этого источника.

Это тестовый APK (debug), не предназначен для публикации в Google Play. Для Play Store позже понадобится подписанный release AAB.
